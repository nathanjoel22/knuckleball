Knuckleball landing page bundle (L1) — lives at plans/l1-landing-bundle.zip in the repo; unpacked by the packet to plans/l1-landing/ — built Oct 21 2026 from the reviewed design.

landing.html            the new marketing page. Final. Becomes index.html in the repo (see packet §4).
media/                  hero film (4 encodes), posters/stills, 13 report + app screenshots (invented test data).
vendor/icons/arm.png    the arm-care tile icon.
_reference/             copies of css/tokens.css, buttons.css, css/components.css and vendor/fonts/* exactly as
                        the page was designed against. FOR DIFFING ONLY — never copy these into the repo;
                        the repo's versions are canonical.
MANIFEST.sha256         checksums of everything above: `shasum -a 256 -c MANIFEST.sha256`
